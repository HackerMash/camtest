# Photo-Picker
Explanation of what the got does. It take a photo of your camera and send it to a discord webhook.

# ⚠️ Warning : 
This is only for educational purposes. I'm not responsable of your actions after using this code.
